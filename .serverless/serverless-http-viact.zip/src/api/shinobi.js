module.exports = router => {
  router.post("/shinobi-frames", (req, res, next) => {
    res
      .send("WIP")
      .status(200)
      .end();
  });
};
