const url = require("url");

console.log(
  url.parse(
    "rtmp://rtmp01open.ys7.com:80/openlive/f01018a141094b7fa138b9d0b856507b"
  )
);
